/* This file DEFINES the function that can multiply two integers */

int cal_multiply (int a, int b)
{
  return (a * b);
}


