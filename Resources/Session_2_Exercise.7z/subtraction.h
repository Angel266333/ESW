/* This file DECLARES the function that can subtract two integers */

int cal_subtract (int a, int b);

