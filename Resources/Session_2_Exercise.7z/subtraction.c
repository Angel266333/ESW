/* This file DEFINES the function that can subtract two integers */
#include "subtraction.h"
