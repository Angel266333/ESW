/* This file DECLARES the function that can add two integers */

int cal_add (int a, int b);

