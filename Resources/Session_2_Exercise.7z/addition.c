/* This file DEFINES the function that can add two integers */

int cal_add (int a, int b)
{
  return (a + b);
}


 