int my_strdiff(char* a, char* b);
int my_strlen(char* a);
int my_strcopy(char* a, char* b);
char* my_strdup(char* a);