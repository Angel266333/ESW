#include <stdio.h>
#include <stdint.h>
#include "LinkedList.h"
#include <stddef.h>




int add_item(void*item, linkedList *list) {
	if (item == NULL || list == NULL) {
		return -1;
	}
	node tmp;
	tmp.data = item;
	tmp.next = NULL;
	//if start is null, we add the object to the first space.
	if (list->start == NULL) {
		list->start = &tmp;
		return 0;
	}
	node* nodePointer = list->start;

	//We override untill the nodePointer object is null;
	while (nodePointer -> next != NULL) {
		nodePointer = nodePointer->next;

	}
	
	nodePointer->next = &tmp;
	return 0;
}

void * get_item(uint16_t index, linkedList *list)
{
	return NULL;
}
int no_of_items(linkedList *list) {

	return 0;

}
int remove_item(void*item, linkedList *list) {
	return 0;
}

